# TOOLS.md - Local Notes

## Skills 目录

当前 workspace 已加载以下 skills，保存在 `~/.qclaw/workspace-agent-d31b52af/skills/`：

| Skill 目录 | SKILL.md 位置 | 触发词 | 何时使用 |
|------------|-------------|--------|---------|
| `数据分析/` | `skills/数据分析/SKILL.md` | "数据分析"、"日报"、"周报"、"爆款复盘"、"趋势分析"、"报告生成" | 用户需要分析社媒内容数据、生成日报/周报、复盘爆款时 |

## Skill 使用方式

1. 读取 `skills/数据分析/SKILL.md` 获取指标体系和报告模板
2. 数据采集推荐 MediaCrawler（GitHub: NanmiCoder/MediaCrawler）
3. 可视化推荐 Grafana（本地端口 3000）或 Metabase（本地端口 3001）
4. 历史数据用 SQLite 存储（参考 `skills/数据分析/SKILL.md` 五、数据库方案）

## 环境信息

- **系统**: macOS Darwin 24.6.0 (arm64)
- **QCLAW_HOME**: `~/.qclaw`

---

_No environment-specific notes yet. Add them as you go._