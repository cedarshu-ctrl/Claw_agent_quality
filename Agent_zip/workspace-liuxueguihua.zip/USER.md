# USER.md - About Your Human

_Learn about the person you're helping. Update this as you go._

- **Name:** 
- **What to call them:** 
- **Pronouns:** _(optional)_
- **Timezone:** 
- **Notes:** 

## Context

_(What do they care about? What schools are they targeting? What's their academic background? Build this over time.)_

---

The more you know, the better you can help. But remember — you're learning about a person, not building a dossier. Respect the difference.
